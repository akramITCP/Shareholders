const de = {
    name: "Name",
    parent: "Elternteil",
    isCompany: "IsCompany",
    Shares: "Aktien",
    TotalShares:"Insgesamt",
    Company: "Persona Jurídica",
    Person: "Persona Física",
    Save:"Gespeichert",
    Error:"Fehler",    
}
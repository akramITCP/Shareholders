const es = {
    Name: "Nombre Completo",
    Parent: "Padre_ID",
    Type: "Tipo de accionista",
    Shares: "% Acciones",
    TotalShares:"Total",
    Company: "Persona Jurídica",
    Person: "Persona Física",
    Save:"Guardado",
    Error:"Error",   
}
const en = {
    Name: "Name",
    Parent: "Parent",
    Type: "Type",
    Shares: "Shares",
    TotalShares:"Total Shares",   
    Company: "Legal Entity",
    Person: "Individual",
    Save:"Saved",
    Error:"Error", 
}